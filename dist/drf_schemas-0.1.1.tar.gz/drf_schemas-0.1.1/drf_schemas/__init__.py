default_app_config = 'drf_schemas.apps.DrfSchemasConfig'
