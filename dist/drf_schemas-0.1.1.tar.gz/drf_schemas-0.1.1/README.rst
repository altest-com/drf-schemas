drf-schemas
=============

Dynamic schema builder api with Django REST Framework.

